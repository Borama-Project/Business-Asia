@extends('auth')

@section('content')
<div ng-view>

</div>

@endsection