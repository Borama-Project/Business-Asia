<div class="col-lg-12"> 
<form>
	<div class="panel panel-info">
	  <div class="panel-body">
	    MainCategory
	  </div>
	</div>
	<div class="form-group col-xs-6">
	    <label for="exampleInputEmail1">Name *</label>
	    <input type="text" class="form-control"  name="name" placeholder="Name">
	</div>
	<div class="form-group col-xs-6">
	    <label for="exampleInputEmail1">Discription</label>
	    <input type="text" class="form-control"  name="name" placeholder="Name">
	</div>
	
	<div class="form-group col-xs-12">
		<button type="submit" class="btn btn-default">Submit</button>
	</div>
  	
</form>
</div>

